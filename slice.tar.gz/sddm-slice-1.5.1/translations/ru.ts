<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>PagePower</name>
    <message>
        <source>Suspend</source>
        <translation>Ждущий режим</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Гибернация</translation>
    </message>
    <message>
        <source>Hybrid Sleep</source>
        <translation>Гибридный сон</translation>
    </message>
</context>
<context>
    <name>PageUsers</name>
    <message>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
</context>
</TS> 
